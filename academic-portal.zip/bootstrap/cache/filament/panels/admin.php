<?php return array (
  'livewireComponents' => 
  array (
    'app.filament.resources.announcement-resource.pages.create-announcement' => 'App\\Filament\\Resources\\AnnouncementResource\\Pages\\CreateAnnouncement',
    'app.filament.resources.announcement-resource.pages.edit-announcement' => 'App\\Filament\\Resources\\AnnouncementResource\\Pages\\EditAnnouncement',
    'app.filament.resources.announcement-resource.pages.list-announcements' => 'App\\Filament\\Resources\\AnnouncementResource\\Pages\\ListAnnouncements',
    'app.filament.resources.course-category-resource.pages.create-course-category' => 'App\\Filament\\Resources\\CourseCategoryResource\\Pages\\CreateCourseCategory',
    'app.filament.resources.course-category-resource.pages.edit-course-category' => 'App\\Filament\\Resources\\CourseCategoryResource\\Pages\\EditCourseCategory',
    'app.filament.resources.course-category-resource.pages.list-course-categories' => 'App\\Filament\\Resources\\CourseCategoryResource\\Pages\\ListCourseCategories',
    'app.filament.resources.course-resource.pages.create-course' => 'App\\Filament\\Resources\\CourseResource\\Pages\\CreateCourse',
    'app.filament.resources.course-resource.pages.edit-course' => 'App\\Filament\\Resources\\CourseResource\\Pages\\EditCourse',
    'app.filament.resources.course-resource.pages.list-courses' => 'App\\Filament\\Resources\\CourseResource\\Pages\\ListCourses',
    'app.filament.resources.exam-session-resource.pages.create-exam-session' => 'App\\Filament\\Resources\\ExamSessionResource\\Pages\\CreateExamSession',
    'app.filament.resources.exam-session-resource.pages.edit-exam-session' => 'App\\Filament\\Resources\\ExamSessionResource\\Pages\\EditExamSession',
    'app.filament.resources.exam-session-resource.pages.list-exam-sessions' => 'App\\Filament\\Resources\\ExamSessionResource\\Pages\\ListExamSessions',
    'app.filament.resources.exam-session-resource.relation-managers.exam-forms-relation-manager' => 'App\\Filament\\Resources\\ExamSessionResource\\RelationManagers\\ExamFormsRelationManager',
    'app.filament.resources.exam-session-resource.relation-managers.exam-session-subjects-relation-manager' => 'App\\Filament\\Resources\\ExamSessionResource\\RelationManagers\\ExamSessionSubjectsRelationManager',
    'app.filament.resources.exam-session-resource.relation-managers.subject-marks-relation-manager' => 'App\\Filament\\Resources\\ExamSessionResource\\RelationManagers\\SubjectMarksRelationManager',
    'app.filament.resources.page-resource.pages.create-page' => 'App\\Filament\\Resources\\PageResource\\Pages\\CreatePage',
    'app.filament.resources.page-resource.pages.edit-page' => 'App\\Filament\\Resources\\PageResource\\Pages\\EditPage',
    'app.filament.resources.page-resource.pages.list-pages' => 'App\\Filament\\Resources\\PageResource\\Pages\\ListPages',
    'app.filament.resources.placement-resource.pages.create-placement' => 'App\\Filament\\Resources\\PlacementResource\\Pages\\CreatePlacement',
    'app.filament.resources.placement-resource.pages.edit-placement' => 'App\\Filament\\Resources\\PlacementResource\\Pages\\EditPlacement',
    'app.filament.resources.placement-resource.pages.list-placements' => 'App\\Filament\\Resources\\PlacementResource\\Pages\\ListPlacements',
    'app.filament.resources.recruiter-resource.pages.create-recruiter' => 'App\\Filament\\Resources\\RecruiterResource\\Pages\\CreateRecruiter',
    'app.filament.resources.recruiter-resource.pages.edit-recruiter' => 'App\\Filament\\Resources\\RecruiterResource\\Pages\\EditRecruiter',
    'app.filament.resources.recruiter-resource.pages.list-recruiters' => 'App\\Filament\\Resources\\RecruiterResource\\Pages\\ListRecruiters',
    'app.filament.resources.role-resource.pages.create-role' => 'App\\Filament\\Resources\\RoleResource\\Pages\\CreateRole',
    'app.filament.resources.role-resource.pages.edit-role' => 'App\\Filament\\Resources\\RoleResource\\Pages\\EditRole',
    'app.filament.resources.role-resource.pages.list-roles' => 'App\\Filament\\Resources\\RoleResource\\Pages\\ListRoles',
    'app.filament.resources.specialization-resource.pages.create-specialization' => 'App\\Filament\\Resources\\SpecializationResource\\Pages\\CreateSpecialization',
    'app.filament.resources.specialization-resource.pages.edit-specialization' => 'App\\Filament\\Resources\\SpecializationResource\\Pages\\EditSpecialization',
    'app.filament.resources.specialization-resource.pages.list-specializations' => 'App\\Filament\\Resources\\SpecializationResource\\Pages\\ListSpecializations',
    'app.filament.resources.student-resource.pages.create-student' => 'App\\Filament\\Resources\\StudentResource\\Pages\\CreateStudent',
    'app.filament.resources.student-resource.pages.edit-student' => 'App\\Filament\\Resources\\StudentResource\\Pages\\EditStudent',
    'app.filament.resources.student-resource.pages.list-students' => 'App\\Filament\\Resources\\StudentResource\\Pages\\ListStudents',
    'app.filament.resources.student-resource.relation-managers.documents-relation-manager' => 'App\\Filament\\Resources\\StudentResource\\RelationManagers\\DocumentsRelationManager',
    'app.filament.resources.subject-resource.pages.create-subject' => 'App\\Filament\\Resources\\SubjectResource\\Pages\\CreateSubject',
    'app.filament.resources.subject-resource.pages.edit-subject' => 'App\\Filament\\Resources\\SubjectResource\\Pages\\EditSubject',
    'app.filament.resources.subject-resource.pages.list-subjects' => 'App\\Filament\\Resources\\SubjectResource\\Pages\\ListSubjects',
    'app.filament.resources.syllabus-resource.pages.create-syllabus' => 'App\\Filament\\Resources\\SyllabusResource\\Pages\\CreateSyllabus',
    'app.filament.resources.syllabus-resource.pages.edit-syllabus' => 'App\\Filament\\Resources\\SyllabusResource\\Pages\\EditSyllabus',
    'app.filament.resources.syllabus-resource.pages.list-syllabi' => 'App\\Filament\\Resources\\SyllabusResource\\Pages\\ListSyllabi',
    'app.filament.resources.user-resource.pages.create-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\CreateUser',
    'app.filament.resources.user-resource.pages.edit-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\EditUser',
    'app.filament.resources.user-resource.pages.list-users' => 'App\\Filament\\Resources\\UserResource\\Pages\\ListUsers',
    'filament.pages.dashboard' => 'Filament\\Pages\\Dashboard',
    'filament.widgets.account-widget' => 'Filament\\Widgets\\AccountWidget',
    'filament.widgets.filament-info-widget' => 'Filament\\Widgets\\FilamentInfoWidget',
    'filament.livewire.database-notifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'filament.pages.auth.edit-profile' => 'Filament\\Pages\\Auth\\EditProfile',
    'filament.livewire.global-search' => 'Filament\\Livewire\\GlobalSearch',
    'filament.livewire.notifications' => 'Filament\\Livewire\\Notifications',
    'filament.pages.auth.login' => 'Filament\\Pages\\Auth\\Login',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    0 => 'Filament\\Pages\\Dashboard',
  ),
  'pageDirectories' => 
  array (
    0 => '/home/whoisyourdaddy/academic-portal/app/Filament/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Pages',
  ),
  'resources' => 
  array (
    '/home/whoisyourdaddy/academic-portal/app/Filament/Resources/AnnouncementResource.php' => 'App\\Filament\\Resources\\AnnouncementResource',
    '/home/whoisyourdaddy/academic-portal/app/Filament/Resources/CourseCategoryResource.php' => 'App\\Filament\\Resources\\CourseCategoryResource',
    '/home/whoisyourdaddy/academic-portal/app/Filament/Resources/CourseResource.php' => 'App\\Filament\\Resources\\CourseResource',
    '/home/whoisyourdaddy/academic-portal/app/Filament/Resources/ExamSessionResource.php' => 'App\\Filament\\Resources\\ExamSessionResource',
    '/home/whoisyourdaddy/academic-portal/app/Filament/Resources/PageResource.php' => 'App\\Filament\\Resources\\PageResource',
    '/home/whoisyourdaddy/academic-portal/app/Filament/Resources/PlacementResource.php' => 'App\\Filament\\Resources\\PlacementResource',
    '/home/whoisyourdaddy/academic-portal/app/Filament/Resources/RecruiterResource.php' => 'App\\Filament\\Resources\\RecruiterResource',
    '/home/whoisyourdaddy/academic-portal/app/Filament/Resources/RoleResource.php' => 'App\\Filament\\Resources\\RoleResource',
    '/home/whoisyourdaddy/academic-portal/app/Filament/Resources/SpecializationResource.php' => 'App\\Filament\\Resources\\SpecializationResource',
    '/home/whoisyourdaddy/academic-portal/app/Filament/Resources/StudentResource.php' => 'App\\Filament\\Resources\\StudentResource',
    '/home/whoisyourdaddy/academic-portal/app/Filament/Resources/SubjectResource.php' => 'App\\Filament\\Resources\\SubjectResource',
    '/home/whoisyourdaddy/academic-portal/app/Filament/Resources/SyllabusResource.php' => 'App\\Filament\\Resources\\SyllabusResource',
    '/home/whoisyourdaddy/academic-portal/app/Filament/Resources/UserResource.php' => 'App\\Filament\\Resources\\UserResource',
  ),
  'resourceDirectories' => 
  array (
    0 => '/home/whoisyourdaddy/academic-portal/app/Filament/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Resources',
  ),
  'widgets' => 
  array (
    0 => 'Filament\\Widgets\\AccountWidget',
    1 => 'Filament\\Widgets\\FilamentInfoWidget',
  ),
  'widgetDirectories' => 
  array (
    0 => '/home/whoisyourdaddy/academic-portal/app/Filament/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Widgets',
  ),
);