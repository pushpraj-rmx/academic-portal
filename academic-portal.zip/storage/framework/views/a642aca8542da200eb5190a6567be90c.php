<?php $__env->startSection('title', $announcement->title . ' - ' . config('app.name')); ?>

<?php $__env->startSection('content'); ?>
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <article>
            <header class="mb-6">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($announcement->published_at): ?>
                    <p class="text-sm text-gray-500 mb-2"><?php echo e($announcement->published_at->format('F j, Y')); ?></p>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <h1 class="text-3xl font-bold text-gray-900"><?php echo e($announcement->title); ?></h1>
            </header>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($announcement->body): ?>
                <div class="prose prose-lg max-w-none text-gray-700 mb-8">
                    <?php echo $announcement->body; ?>

                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($announcement->attachment): ?>
                <p class="mt-6">
                    <a href="<?php echo e(\Illuminate\Support\Facades\Storage::url($announcement->attachment)); ?>" target="_blank" rel="noopener" class="inline-flex items-center gap-2 px-4 py-2 bg-amber-600 text-white rounded-lg hover:bg-amber-700 font-medium">
                        Download PDF
                    </a>
                </p>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </article>

        <p class="mt-8">
            <a href="<?php echo e(route('notices.index')); ?>" class="text-amber-600 hover:text-amber-700 font-medium">&larr; Back to Notices</a>
        </p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/whoisyourdaddy/academic-portal/resources/views/public/notices/show.blade.php ENDPATH**/ ?>