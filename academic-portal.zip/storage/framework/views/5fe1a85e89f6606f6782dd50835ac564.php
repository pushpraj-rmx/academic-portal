<?php
    $announcements = \App\Models\Announcement::published()->latest('published_at')->limit(5)->get();
?>
<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($announcements->isNotEmpty()): ?>
    <div class="bg-amber-50 border-y border-amber-200 py-2 overflow-hidden">
        <div class="max-w-6xl mx-auto px-4 flex items-center gap-4">
            <span class="text-amber-800 font-semibold shrink-0">Notices:</span>
            <div class="flex gap-6 overflow-x-auto">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $announcements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $announcement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('notices.show', $announcement)); ?>" class="text-gray-700 hover:text-amber-700 hover:underline">
                        <?php echo e($announcement->title); ?>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($announcement->published_at): ?>
                            <span class="text-gray-500 text-sm">(<?php echo e($announcement->published_at->format('M d, Y')); ?>)</span>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>
    </div>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php /**PATH /home/whoisyourdaddy/academic-portal/resources/views/components/public/announcement-ticker.blade.php ENDPATH**/ ?>