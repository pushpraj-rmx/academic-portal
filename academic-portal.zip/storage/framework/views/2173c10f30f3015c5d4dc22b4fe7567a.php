<?php $__env->startSection('title', ($student ? 'Results - ' . $student->user->name : 'Results') . ' - ' . config('app.name')); ?>
<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
    <h1 class="text-3xl font-bold text-gray-900 mb-8">Exam Results</h1>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(! $student): ?>
        <p class="text-gray-600">No student found with that roll number or enrollment ID.</p>
        <a href="<?php echo e(route('results.index')); ?>" class="inline-block mt-4 text-amber-600 hover:text-amber-700 font-medium">Search again</a>
    <?php else: ?>
    <div class="mb-8">
        <p class="text-gray-700"><strong>Name:</strong> <?php echo e($student->user->name); ?></p>
        <p class="text-gray-700"><strong>Course:</strong> <?php echo e($student->course->name); ?></p>
        <p class="text-gray-700"><strong>Roll No:</strong> <?php echo e($student->roll_number); ?></p>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(empty($resultsBySession)): ?>
        <p class="text-gray-600">No published results found for this student.</p>
    <?php else: ?>
        <div class="space-y-8">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $resultsBySession; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $session = $item['session'];
                    $result = $item['result'];
                ?>
                <div class="bg-white rounded-lg border border-gray-200 p-6 shadow-sm">
                    <h2 class="text-xl font-semibold text-gray-900 mb-4"><?php echo e($session->name); ?></h2>
                    <p class="text-sm text-gray-500 mb-4"><?php echo e($session->academic_year); ?> · <?php echo e($session->session_type); ?></p>

                    <table class="min-w-full divide-y divide-gray-200 mb-4">
                        <thead class="bg-gray-50">
                            <tr>
                                <th scope="col" class="py-2 px-3 text-left text-xs font-medium text-gray-500 uppercase">Subject</th>
                                <th scope="col" class="py-2 px-3 text-right text-xs font-medium text-gray-500 uppercase">Marks</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $result['subject_marks_detail'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="py-2 px-3 text-sm text-gray-900"><?php echo e($sm->subject->name ?? $sm->subject_id); ?></td>
                                    <td class="py-2 px-3 text-sm text-right"><?php echo e($sm->is_absent ? 'Absent' : ($sm->marks_obtained ?? '—')); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </tbody>
                    </table>

                    <div class="flex flex-wrap gap-4 text-sm">
                        <span><strong>Total:</strong> <?php echo e(number_format($result['marks_obtained'], 2)); ?> / <?php echo e(number_format($result['total_marks'], 2)); ?></span>
                        <span><strong>Percentage:</strong> <?php echo e(number_format($result['percentage'], 2)); ?>%</span>
                        <span><strong>Grade:</strong> <?php echo e($result['grade']); ?></span>
                        <span>
                            <strong>Status:</strong>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($result['is_passed']): ?>
                                <span class="text-green-600 font-medium">Passed</span>
                            <?php else: ?>
                                <span class="text-red-600 font-medium">Failed</span>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </span>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <a href="<?php echo e(route('results.index')); ?>" class="inline-block mt-8 text-amber-600 hover:text-amber-700 font-medium">Search again</a>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/whoisyourdaddy/academic-portal/resources/views/public/results/show.blade.php ENDPATH**/ ?>