<?php $__env->startSection('title', $page->meta_description ?: $page->title . ' - ' . config('app.name')); ?>

<?php $__env->startSection('content'); ?>
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <article>
            <h1 class="text-3xl font-bold text-gray-900 mb-6"><?php echo e($page->title); ?></h1>
            <div class="prose prose-lg max-w-none text-gray-700">
                <?php echo $page->body; ?>

            </div>
        </article>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/whoisyourdaddy/academic-portal/resources/views/public/page.blade.php ENDPATH**/ ?>