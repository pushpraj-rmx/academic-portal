<?php $__env->startSection('title', 'Results - ' . config('app.name')); ?>
<?php $__env->startSection('content'); ?>
<div class="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
    <h1 class="text-3xl font-bold text-gray-900 mb-6">Check Results</h1>
    <p class="text-gray-600 mb-8">Enter your roll number or enrollment ID to view your exam results.</p>
    <form action="<?php echo e(route('results.search')); ?>" method="get" class="bg-white rounded-lg border border-gray-200 p-6 shadow-sm">
        <div class="space-y-4">
            <div>
                <label for="query" class="block text-sm font-medium text-gray-700">Roll number or Enrollment ID</label>
                <input type="text" name="query" id="query" value="<?php echo e(old('query')); ?>"
                    class="mt-1 block w-full rounded-md border border-gray-300 shadow-sm py-2 px-3 focus:border-amber-500 focus:ring-amber-500 sm:text-sm"
                    required maxlength="255" placeholder="e.g. 2024CS001 or ENR-12345">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['query'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
            <button type="submit" class="inline-flex items-center px-4 py-2 bg-amber-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-amber-700 focus:bg-amber-700 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:ring-offset-2 transition ease-in-out duration-150">
                Search
            </button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/whoisyourdaddy/academic-portal/resources/views/public/results/index.blade.php ENDPATH**/ ?>