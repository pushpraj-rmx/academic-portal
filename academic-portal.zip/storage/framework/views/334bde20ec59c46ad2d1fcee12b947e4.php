<?php $__env->startSection('title', 'Our Recruiters - ' . config('app.name')); ?>
<?php $__env->startSection('content'); ?>
<div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
    <h1 class="text-3xl font-bold text-gray-900 mb-8">Our Recruiters</h1>
    <p class="text-gray-600 mb-6"><a href="<?php echo e(route('placements.statistics')); ?>" class="text-amber-600 hover:text-amber-700 font-medium">View placement statistics</a></p>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($recruiters->isEmpty()): ?>
        <p class="text-gray-600">No recruiters to display.</p>
    <?php else: ?>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $recruiters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recruiter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white rounded-lg border border-gray-200 p-6 shadow-sm flex flex-col items-center text-center">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($recruiter->logo_path): ?>
                        <img src="<?php echo e(Storage::disk('public')->url($recruiter->logo_path)); ?>" alt="<?php echo e($recruiter->name); ?>" class="h-16 w-auto object-contain mb-4">
                    <?php else: ?>
                        <div class="h-16 w-16 rounded bg-gray-100 flex items-center justify-center mb-4 text-gray-400 font-semibold text-lg"><?php echo e(Str::substr($recruiter->name, 0, 2)); ?></div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <h2 class="text-lg font-semibold text-gray-900"><?php echo e($recruiter->name); ?></h2>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($recruiter->website): ?>
                        <a href="<?php echo e($recruiter->website); ?>" target="_blank" rel="noopener noreferrer" class="mt-2 text-amber-600 hover:text-amber-700 text-sm font-medium">Visit website</a>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/whoisyourdaddy/academic-portal/resources/views/public/placements/recruiters.blade.php ENDPATH**/ ?>