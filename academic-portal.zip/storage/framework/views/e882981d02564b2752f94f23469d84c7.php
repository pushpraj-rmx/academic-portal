<footer class="bg-white border-t border-gray-200 mt-auto">
    <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div class="text-center text-sm text-gray-500">
            <p>&copy; <?php echo e(date('Y')); ?> <?php echo e(config('app.name')); ?>. All rights reserved.</p>
        </div>
    </div>
</footer>
<?php /**PATH /home/whoisyourdaddy/academic-portal/resources/views/components/public/footer.blade.php ENDPATH**/ ?>