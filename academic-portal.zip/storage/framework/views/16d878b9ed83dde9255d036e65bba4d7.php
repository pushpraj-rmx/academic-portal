<header class="bg-white border-b border-gray-200 shadow-sm">
    <nav class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8" aria-label="Main navigation">
        <div class="flex justify-between items-center h-16">
            <a href="<?php echo e(route('home')); ?>" class="text-xl font-semibold text-gray-800 hover:text-gray-600">
                <?php echo e(config('app.name')); ?>

            </a>
            <div class="flex items-center gap-6">
                <a href="<?php echo e(route('home')); ?>" class="text-gray-600 hover:text-gray-900 font-medium">Home</a>
                <a href="<?php echo e(route('pages.show', ['page' => 'about'])); ?>" class="text-gray-600 hover:text-gray-900 font-medium">About</a>
                <a href="<?php echo e(route('academic.index')); ?>" class="text-gray-600 hover:text-gray-900 font-medium">Courses</a>
                <a href="<?php echo e(route('notices.index')); ?>" class="text-gray-600 hover:text-gray-900 font-medium">Notices</a>
                <a href="<?php echo e(route('results.index')); ?>" class="text-gray-600 hover:text-gray-900 font-medium">Results</a>
                <a href="<?php echo e(route('placements.recruiters')); ?>" class="text-gray-600 hover:text-gray-900 font-medium">Placements</a>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(url('/dashboard')); ?>" class="text-gray-600 hover:text-gray-900 font-medium">Dashboard</a>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()->can('page.view')): ?>
                        <a href="<?php echo e(url('/admin')); ?>" class="text-amber-600 hover:text-amber-700 font-medium">Admin</a>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" class="text-gray-600 hover:text-gray-900 font-medium">Login</a>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>
    </nav>
</header>
<?php /**PATH /home/whoisyourdaddy/academic-portal/resources/views/components/public/header.blade.php ENDPATH**/ ?>